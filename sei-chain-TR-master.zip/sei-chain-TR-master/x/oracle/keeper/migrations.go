package keeper

import (
	sdk "github.com/cosmos/cosmos-sdk/types"

	"github.com/sei-protocol/sei-chain/x/oracle/types"
)

// Migrator is a struct for handling in-place store migrations.
type Migrator struct {
	keeper Keeper
}

// NewMigrator returns a new Migrator.
func NewMigrator(keeper Keeper) Migrator {
	return Migrator{keeper: keeper}
}

// Migrate2to3 migrates from version 2 to 3.
func (m Migrator) Migrate2to3(ctx sdk.Context) error {
	store := ctx.KVStore(m.keeper.storeKey)

	iter := sdk.KVStorePrefixIterator(store, types.ExchangeRateKey)
	defer iter.Close()
	for ; iter.Valid(); iter.Next() {
		dp := sdk.DecProto{}
		m.keeper.cdc.MustUnmarshal(iter.Value(), &dp)
		// create proto for new data value
		// because we don't have a lastUpdate, we set it to 0
		rate := types.OracleExchangeRate{ExchangeRate: dp.Dec, LastUpdate: sdk.ZeroInt()}
		bz := m.keeper.cdc.MustMarshal(&rate)
		store.Set(iter.Key(), bz)
	}

	return nil
}
