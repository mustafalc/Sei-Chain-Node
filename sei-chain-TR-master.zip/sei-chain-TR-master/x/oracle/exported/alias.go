//nolint:deadcode,unused
//DONTCOVER
package exported

import "github.com/sei-protocol/sei-chain/x/oracle/types"

type (
	MsgAggregateExchangeRatePrevote = types.MsgAggregateExchangeRatePrevote
	MsgAggregateExchangeRateVote    = types.MsgAggregateExchangeRateVote
)
