# Sei modules

Sei implements the following custom modules:
* `dex` -
* `epoch` -
* `oracle` -