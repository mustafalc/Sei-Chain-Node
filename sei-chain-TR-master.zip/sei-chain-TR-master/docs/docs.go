package docs

import "embed"

//go:embed static
var Docs embed.FS
